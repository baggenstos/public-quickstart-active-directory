﻿function Set-TargetResource
{
    # Should process is called in a helper functions but not directly in Set-TargetResource
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSShouldProcess', '')]
    [CmdletBinding(SupportsShouldProcess = $true)]
    param
    (
        [parameter(Mandatory)]
        [System.String] $DriveLetter,

        [parameter(Mandatory)]
        [uint32] $DiskNumber,

        [UInt64] $Size,

        [System.String] $FSLabel,

        [UInt32] $AllocationUnitSize,

        [ValidateSet("NTFS","ReFS")]
        [System.String]
        $FSFormat = 'NTFS'
    )

    Write-Verbose -Message "Starting disk configuration for Disk Number $DiskNumber with Drive Letter $DriveLetter" # <<< Changed

    $disk = Get-Disk -Number $DiskNumber -ErrorAction Stop

    if ($disk.IsOffline)
    {
        Write-Verbose -Message "Bringing disk $DiskNumber online" # <<< Changed
        $disk | Set-Disk -IsOffline $false
    }

    if ($disk.IsReadOnly)
    {
        Write-Verbose -Message "Making disk $DiskNumber read-write" # <<< Changed
        $disk | Set-Disk -IsReadOnly $false
    }

    # Check and initialize disk if RAW or re-initialize if needed
    if ($disk.PartitionStyle -eq "RAW")
    {
        Write-Verbose -Message "Initializing disk $DiskNumber as GPT" # <<< Changed
        $disk | Initialize-Disk -PartitionStyle "GPT"
    }
    elseif ($disk.PartitionStyle -ne "GPT")
    {
        Write-Verbose -Message "Removing existing partitions to re-initialize disk $DiskNumber as GPT" # <<< Changed
        $disk | Get-Partition | Remove-Partition -Confirm:$false
        $disk | Initialize-Disk -PartitionStyle "GPT"
    }

    # Wait for disk to become available
    Start-Sleep -Seconds 5 # <<< Changed

    # Check for existing partitions, and remove if necessary
    $existingPartition = $disk | Get-Partition -ErrorAction SilentlyContinue
    if ($existingPartition)
    {
        Write-Verbose -Message "Removing existing partition on disk $DiskNumber" # <<< Changed
        $existingPartition | Remove-Partition -Confirm:$false
    }

    # Partition and format the disk
    Write-Verbose -Message "Creating new partition on disk $DiskNumber" # <<< Changed
    $partitionParams = @{
        DiskNumber = $DiskNumber
        DriveLetter = $DriveLetter
        UseMaximumSize = $true
    }
    
    $partition = New-Partition @partitionParams

    # Wait for partition to be available for formatting
    Start-Sleep -Seconds 5 # <<< Changed

    # Prepare formatting parameters
    $volParams = @{
        FileSystem = $FSFormat
        Confirm = $false
    }

    if ($FSLabel)
    {
        $volParams["NewFileSystemLabel"] = $FSLabel
    }

    if ($AllocationUnitSize)
    {
        $volParams["AllocationUnitSize"] = $AllocationUnitSize
    }

    # Format the partition
    Write-Verbose -Message "Formatting partition with FileSystem $FSFormat and Drive Letter $DriveLetter" # <<< Changed
    $volume = $partition | Format-Volume @volParams -ErrorAction Stop # <<< Changed

    if ($volume)
    {
        Write-Verbose -Message "Successfully formatted Disk $DiskNumber with Drive Letter $DriveLetter as $FSFormat" # <<< Changed
    }
    else
    {
        Write-Verbose -Message "Failed to format Disk $DiskNumber" # <<< Changed
    }
} # Set-TargetResource
